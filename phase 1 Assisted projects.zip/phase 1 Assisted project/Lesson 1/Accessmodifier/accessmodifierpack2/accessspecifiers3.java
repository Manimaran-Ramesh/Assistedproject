package accessmodifierpack2;

import accessmodifierpack1.*;

public class accessspecifiers3 extends proaccessspecifiers {

	public static void main(String[] args) {
		accessspecifiers3 obj = new accessspecifiers3 ();   
	       obj.display();  
	}

}
