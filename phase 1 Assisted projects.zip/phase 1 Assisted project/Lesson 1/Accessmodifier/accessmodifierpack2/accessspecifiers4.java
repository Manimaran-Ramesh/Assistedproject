package accessmodifierpack2;

import accessmodifierpack1.*;

public class accessspecifiers4 {

	public static void main(String[] args) {
		
		proaccessspecifiers obj = new proaccessspecifiers(); 
        obj.display();  
		
	}
}
