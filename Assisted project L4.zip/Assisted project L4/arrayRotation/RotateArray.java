package arrayRotation;
class Rotate_Array { 
public void rotate(int[] nums, int k) {
    		if(k > nums.length) 
       			k=k%nums.length;
 		int[] res = new int[nums.length];
 		for(int i=0; i < k; i++){
        			res[i] = nums[nums.length-k+i];
 		}
 		int j=0;
    		for(int i=k; i<nums.length; i++){
        			res[i] = nums[j];
j++;
    		}
 		System.arraycopy( res, 0, nums, 0, nums.length );
}
} 
public class RotateArray
{
	public static void main(String[] args) 
	{
		Rotate_Array ro = new Rotate_Array();
        		int arr[] = { 7,6,5,4,3,2,1 }; 
        		ro.rotate(arr, 5); 
        		for(int j=0;j<arr.length;j++){
            			System.out.print(arr[j]+" ");
        		}
	}
}